import React from 'react';

const GigsPage = () => {
  return <div />;
};

export default GigsPage;
