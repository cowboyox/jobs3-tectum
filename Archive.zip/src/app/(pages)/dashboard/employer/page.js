import React from 'react';

const EmployerDashboard = () => {
  return <div />;
};

export default EmployerDashboard;
