Deployment Version: V1.7

# 👏Hello Everyone!
-------------------------------
## ✔Frontend developers can start development by creating their own branch and pulling from the "develop" branch.
## ✔Once completed the functions, confirm the if there are not any bugs and issues when deploy on the vercel.
## ✔Then merge to develop branch, and confirm if it is deployed on the vercel without any bugs.
