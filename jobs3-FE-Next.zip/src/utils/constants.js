const skillSets = [
    'UI/UX',
    'Design',
    'Webdesign',
    'Prototyping',
    'Wireframing',
    'Research'
];

const languages = [
    'English',
    'Germany',
    'Russian',
    'Spanish',
    'Portugues'
];

export { skillSets, languages };