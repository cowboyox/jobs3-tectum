// const backend_url = 'http://127.0.0.1:5462'
const backend_url = 'https://jobs3-backend.vercel.app'

module.exports = {
    backend_url
}