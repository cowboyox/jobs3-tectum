import React from 'react'

const GigsPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default GigsPage
