import React from 'react'; 

/*
 - Selmani: i abandoned this page in it's beggining of the progress lol
 * That's cause i have now to finish the gig page first, but if somehow  
 * you need to create it, feel free to use the FormStep folder on the components
 
 - For now i delted everything here
 
 - NOTE: Better not to use "use client", if you don't know how, please just text me and 
 * i will give more details
*/

const CreatePortfolio = () => {
    return (
      <></> 
    );
};

export default CreatePortfolio;